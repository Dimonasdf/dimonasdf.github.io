﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	public static class ScoreHandler
	{

		public static int Score { get; set; }
		public static float Time { get; set; }

		public static void AddPoints(int value)
		{
			Score += value;
		}

		public static void NullScore()
		{
			Score = 0;
			Time = 0;
		}

		static int minutes = 0;

		public static string TimeToMinutes(float time)
		{
			if (Time >= 60)
			{
				minutes += 1;
				Time -= 60;
			}
			return string.Format("{0} Min, {1:0.000} Sec", minutes, time);
		}
	}
}

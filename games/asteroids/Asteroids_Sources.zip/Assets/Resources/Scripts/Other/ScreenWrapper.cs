﻿using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	public class ScreenWrapper : MonoBehaviour
	{
		float colliderRadius;
		const short OffsetDenominator = 10;
		float offsetValue;

		Vector3 position;

		void Start()
		{
			if (GetComponent<CircleCollider2D>() != null)
			{
				colliderRadius = GetComponent<CircleCollider2D>().radius;
			}
			else
			{
				colliderRadius = 0;
			}

			offsetValue = colliderRadius / OffsetDenominator;
		}

		private void FixedUpdate()
		{
			position = transform.position;

			// check left, right, top, and bottom sides
			if (position.x + colliderRadius < ScreenUtils.ScreenLeft)
				position.x = ScreenUtils.ScreenRight - offsetValue;

			if (position.x - colliderRadius > ScreenUtils.ScreenRight)
				position.x = ScreenUtils.ScreenLeft + offsetValue;

			if (position.y + colliderRadius < ScreenUtils.ScreenBottom)
				position.y = ScreenUtils.ScreenTop - offsetValue;

			if (position.y - colliderRadius > ScreenUtils.ScreenTop)
				position.y = ScreenUtils.ScreenBottom + offsetValue;

			// move object
			transform.position = position;
		}
	}
}

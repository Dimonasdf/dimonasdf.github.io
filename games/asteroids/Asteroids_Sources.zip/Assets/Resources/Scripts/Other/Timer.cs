﻿using System;
using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	public class Timer : MonoBehaviour
	{
		#region Fields

		float totalSeconds = 0f;
		float elapsedSeconds = 0f;
		bool running = false;
		bool started = false;

		#endregion


		#region Properties

		public float Duration
		{
			set { if (!running) { totalSeconds = value; } }
		}

		public bool Finished
		{
			get { return started && !running; }
		}

		public bool Running
		{
			get { return running; }
		}

		public float ElapsedSeconds
		{
			get { return elapsedSeconds; }
		}

		#endregion


		#region Method

		public void Run()
		{
			if (totalSeconds > 0)
			{
				elapsedSeconds = 0f;
				started = true;
				running = true;

			}
		}

		#endregion


		#region Unity

		void Update()
		{
			if (running)
			{
				elapsedSeconds += Time.deltaTime;
				if (elapsedSeconds >= totalSeconds)
				{
					running = false;
				}
			}
		}

		#endregion
	}
}

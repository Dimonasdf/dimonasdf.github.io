﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	// Initializes the game
	public class GameInitializer : MonoBehaviour
	{
		void Awake()
		{
			// initialize screen utils
			ScreenUtils.Initialize();
		}
	}
}

﻿using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	/// <summary>
	/// Provides screen calculations and force math
	/// </summary>
	public static class ScreenUtils
	{
		#region Fields

		// cached for efficient boundary checking
		static float screenLeft;
		static float screenRight;
		static float screenTop;
		static float screenBottom;
		static float screenMiddleX;
		static float screenMiddleY;
		static float screenZ;

		static Vector3 startPositionLeft;
		static Vector3 startPositionBot;
		static Vector3 startPositionRight;
		static Vector3 startPositionTop;

		#endregion

		#region Properties

		public static float ScreenLeft
		{
			get { return screenLeft; }
		}

		public static float ScreenRight
		{
			get { return screenRight; }
		}

		public static float ScreenTop
		{
			get { return screenTop; }
		}

		public static float ScreenBottom
		{
			get { return screenBottom; }
		}

		public static float ScreenMiddleX
		{
			get { return screenMiddleX; }
		}

		public static float ScreenMiddleY
		{
			get { return screenMiddleY; }
		}

		public static Vector3 StartPositionLeft
		{
			get { return startPositionLeft; }
		}
		public static Vector3 StartPositionBot
		{
			get { return startPositionBot; }
		}
		public static Vector3 StartPositionRight
		{
			get { return startPositionRight; }
		}
		public static Vector3 StartPositionTop
		{
			get { return startPositionTop; }
		}

		#endregion


		#region Methods

		public static void Initialize()
		{
			// save screen edges in world coordinates
			screenZ = -Camera.main.transform.position.z;
			Vector3 lowerLeftCornerScreen = new Vector3(0, 0, screenZ);
			Vector3 upperRightCornerScreen = new Vector3(Screen.width, Screen.height, screenZ);

			Vector3 middleScreen = new Vector3(Screen.width / 2, Screen.height / 2, screenZ);

			Vector3 lowerLeftCornerWorld = Camera.main.ScreenToWorldPoint(lowerLeftCornerScreen);
			Vector3 upperRightCornerWorld = Camera.main.ScreenToWorldPoint(upperRightCornerScreen);

			Vector3 middleWorld = Camera.main.ScreenToWorldPoint(middleScreen);


			screenLeft = lowerLeftCornerWorld.x;
			screenRight = upperRightCornerWorld.x;
			screenTop = upperRightCornerWorld.y;
			screenBottom = lowerLeftCornerWorld.y;

			screenMiddleX = middleWorld.x;
			screenMiddleY = middleWorld.y;

			startPositionLeft = new Vector3(ScreenLeft, ScreenMiddleY, 1);
			startPositionBot = new Vector3(ScreenMiddleX, ScreenBottom, 1);
			startPositionRight = new Vector3(ScreenRight, ScreenMiddleY, 1);
			startPositionTop = new Vector3(ScreenMiddleX, ScreenTop, 1);

		}

		public static Vector2 ForceDirection(GameObject gameObject)
		{
			float zRotation = gameObject.transform.eulerAngles.z * Mathf.Deg2Rad;
			Vector2 forceDirection;
			forceDirection.x = Mathf.Cos(zRotation);
			forceDirection.y = Mathf.Sin(zRotation);
			return new Vector2(forceDirection.x, forceDirection.y);
		}


		#endregion
	}
}

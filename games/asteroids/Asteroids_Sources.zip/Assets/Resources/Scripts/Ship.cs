﻿using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	/// <summary>
	/// A ship
	/// </summary>
	public class Ship : MonoBehaviour
	{

		#region Fields

		// thrust and rotation support
		Rigidbody2D rb2D;
		public Vector2 ThrustDirection;


		float rotationInput;
		float rotationAmount;

		[SerializeField]
		GameObject prefabLaser;
		[SerializeField]
		GameObject prefabLaserDouble;
		[SerializeField]
		GameObject prefabExplosion;

		Timer shootTimer;
		bool canShoot = false;

		#endregion



		void Start()
		{
			ThrustDirection = new Vector2(1, 0);

			// saved for efficiency
			rb2D = GetComponent<Rigidbody2D>();

			shootTimer = gameObject.AddComponent<Timer>();
			shootTimer.Duration = GlobalConfig.LaserShotCooldown;
			shootTimer.Run();
		}//start


		void Update()
		{
			// check for rotation input
			rotationInput = Input.GetAxis("Rotate");
			if (rotationInput != 0)
			{

				// calculate rotation amount and apply rotation
				rotationAmount = GlobalConfig.ShipRotateDegreesPerSecond * Time.deltaTime;
				if (rotationInput < 0)
				{
					rotationAmount *= -1;
				}
				transform.Rotate(Vector3.forward, rotationAmount);

				// change thrust direction to match ship rotation
				ThrustDirection = ScreenUtils.ForceDirection(gameObject);
			}

			if (shootTimer.Finished)
			{
				canShoot = true;
			}

			//fire1

			if (Input.GetButtonDown("Fire1") && canShoot)
			{
				Vector3 shipPosition = gameObject.transform.position;

				if (Input.GetButton("Shift"))
				{
					Instantiate<GameObject>(prefabLaserDouble, new Vector3(shipPosition.x, shipPosition.y, shipPosition.z + 1), Quaternion.identity);

					AudioManager.SfxPlay(AudioClipName.LaserShot);
					//AudioManager.Play(AudioManager.clipLaser);
				}
				else
				{
					Instantiate<GameObject>(prefabLaser, new Vector3(shipPosition.x, shipPosition.y, shipPosition.z + 1), Quaternion.identity);

					AudioManager.SfxPlay(AudioClipName.LaserShot, GlobalConfig.SimpleLaserShotPitch);
					//AudioManager.Play(AudioManager.clipLaser);
				}

				canShoot = false;
				shootTimer.Run();
			}

		}//update


		// FixedUpdate is called 50 times per second
		void FixedUpdate()
		{


			// thrust as appropriate
			if (Input.GetAxis("Thrust") > 0)
			{
				rb2D.AddForce(GlobalConfig.ShipThrustForce * ThrustDirection, ForceMode2D.Force);
			}
			if (Input.GetAxis("Thrust") < 0)
			{
				rb2D.AddForce(-GlobalConfig.ShipThrustForce * ThrustDirection, ForceMode2D.Force);
			}



		}//fixedupdate


		void OnCollisionEnter2D(Collision2D collision)
		{
			if (collision.gameObject.tag == "Asteroid")
			{
				Instantiate<GameObject>(prefabExplosion, gameObject.transform.position, Quaternion.identity);
				AudioManager.SfxPlay(AudioClipName.Explosion, GlobalConfig.PlayerDeathExplosionPitch);
				Destroy(gameObject);

				MySceneManager.PlayScene(MenuNames.EndMenu);
			}
		}//oncollision
	}//class
}//namespace

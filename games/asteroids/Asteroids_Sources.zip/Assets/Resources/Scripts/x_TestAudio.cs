﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class x_TestAudio : MonoBehaviour
{
	AudioClip clip;

    void Start()
    {
		clip = Resources.Load<AudioClip>("Audio/Laser");

		gameObject.AddComponent<AudioSource>();

		gameObject.GetComponent<AudioSource>().loop = true;
		gameObject.GetComponent<AudioSource>().PlayOneShot(clip);

	}

}

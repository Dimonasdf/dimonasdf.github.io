﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	public static class AudioManager
	{
		public static bool Initialized { get; set; }

		public static AudioSource sfxAudioSource;
		public static AudioSource bgmAudioSource;

		static Dictionary<AudioClipName, AudioClip> audioClips = new Dictionary<AudioClipName, AudioClip>();

		public static void Initialize(AudioSource sfxSource, AudioSource bgmSource)
		{
			Initialized = true;
			sfxAudioSource = sfxSource;
			bgmAudioSource = bgmSource;

			audioClips.Add(AudioClipName.Explosion, Resources.Load<AudioClip>("Audio/Explosion"));
			audioClips.Add(AudioClipName.LaserShot, Resources.Load<AudioClip>("Audio/Laser"));
			audioClips.Add(AudioClipName.BackgroundMusic, Resources.Load<AudioClip>("Audio/Ode-to-dub-step"));
		}

		//base case
		public static void SfxPlay(AudioClipName name)
		{
			sfxAudioSource.volume = GlobalConfig.MasterVolume * GlobalConfig.SfxVolume;

			float randomPitch = UnityEngine.Random.Range(GlobalConfig.LowPitchRange, GlobalConfig.HighPitchRange);
			sfxAudioSource.pitch = randomPitch;

			sfxAudioSource.PlayOneShot(audioClips[name]);
		}

		//when we need to mod it
		public static void SfxPlay(AudioClipName name, float pitchMod)
		{
			sfxAudioSource.volume = GlobalConfig.MasterVolume * GlobalConfig.SfxVolume;

			float randomPitch = UnityEngine.Random.Range(GlobalConfig.LowPitchRange, GlobalConfig.HighPitchRange);
			sfxAudioSource.pitch = randomPitch * pitchMod;

			sfxAudioSource.PlayOneShot(audioClips[name]);
		}

		//bgm source
		public static void BgmPlay(AudioClipName name)
		{
			bgmAudioSource.volume = GlobalConfig.MasterVolume * GlobalConfig.BgmVolume;

			bgmAudioSource.loop = true;

			bgmAudioSource.clip = audioClips[name];
			bgmAudioSource.Play();
		}

	}
}

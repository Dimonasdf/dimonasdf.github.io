﻿namespace AsteroidGame
{
	public enum AudioClipName
	{
		LaserShot,
		Explosion,
		BackgroundMusic

	}
}

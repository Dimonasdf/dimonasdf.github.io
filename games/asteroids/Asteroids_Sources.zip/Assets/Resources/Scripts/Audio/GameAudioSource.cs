﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	public class GameAudioSource : MonoBehaviour
	{

		private void Awake()
		{

			if (!AudioManager.Initialized)
			{
				AudioSource sfxAudioSource = gameObject.AddComponent<AudioSource>();
				AudioSource bgmAudioSource = gameObject.AddComponent<AudioSource>();

				AudioManager.Initialize(sfxAudioSource, bgmAudioSource);

				DontDestroyOnLoad(gameObject);
			}
			else
			{
				Destroy(gameObject);
			}
		}

		private void Start()
		{
			AudioManager.BgmPlay(AudioClipName.BackgroundMusic);
		}
	}
}

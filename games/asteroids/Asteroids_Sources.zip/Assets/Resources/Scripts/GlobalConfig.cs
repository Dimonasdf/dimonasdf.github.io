﻿namespace AsteroidGame
{
	public static class GlobalConfig
	{
		#region Audio

		public static float MasterVolume = 0.2f;
		public static float SfxVolume = 1f;
		public static float BgmVolume = 1f;

		public const float LowPitchRange = 0.9f;
		public const float HighPitchRange = 1.1f;

		public const float BigAsteroidExplosionPitch = 1.5f;
		public const float SimpleLaserShotPitch = 0.9f;

		public const float PlayerDeathExplosionPitch = 0.5f;

		#endregion


		#region Laser

		public const float LaserImpulseForce = 10000f;
		public const float LaserSuicideTime = 0.8f;

		public const float LaserShotCooldown = 0.1f;

		//laser mass

		#endregion


		#region Asteroid

		public const float BigAsteroidSpawnTime = 3f;

		public const float BigAsteroidMinInpulseForce = 30f;
		public const float BigAsteroidMaxImpulseForce = 40f;

		//asteroid mass


		public const float SmallAsteroidMagnitude = 30f;

		public const int SmallAsteroidScoreValue = 1;
		public const int BigAsteroidScoreValue = 2;

		public const float SwitchLayerTimerDuration = 0.11f;


		#endregion


		#region Ship

		public const float ShipThrustForce = 4.2f;
		public const float ShipRotateDegreesPerSecond = 220f;

		//ship mass

		#endregion





	}
}

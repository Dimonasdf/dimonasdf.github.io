﻿namespace AsteroidGame
{
	public enum MenuNames
	{
		StartMenu,
		GamePlay,
		EndMenu,
		Options
	}
}

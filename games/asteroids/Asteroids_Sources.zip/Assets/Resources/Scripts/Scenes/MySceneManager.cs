﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


namespace AsteroidGame
{
	public static class MySceneManager
	{
		public static void PlayScene(MenuNames name)
		{
			switch (name)
			{
				case MenuNames.StartMenu:

					SceneManager.LoadScene("Assets/Resources/_Scenes/0_StartMenu.unity");
					break;

				case MenuNames.GamePlay:

					SceneManager.LoadScene("Assets/Resources/_Scenes/1_GamePlay.unity");
					break;

				case MenuNames.EndMenu:

					SceneManager.LoadScene("Assets/Resources/_Scenes/2_EndMenu.unity");
					break;

				case MenuNames.Options:
					SceneManager.LoadScene("Assets/Resources/_Scenes/3_OptionsMenu.unity");
					break;
			}

			/*	case MenuNames.Pause:
					// instantiate prefab
					Object.Instantiate(Resources.Load("PauseMenu"));
					break;
			*/
		}
	}
}

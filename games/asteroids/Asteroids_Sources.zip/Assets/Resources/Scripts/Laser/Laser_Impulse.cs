﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AsteroidGame
{
	public class Laser_Impulse : MonoBehaviour
	{
		Rigidbody2D rb2D;
		Vector2 impulseDirection;

		void Start()
		{
			rb2D = GetComponent<Rigidbody2D>();

			impulseDirection = GameObject.FindWithTag("Player").GetComponent<Ship>().ThrustDirection;

			rb2D.AddForce(impulseDirection * GlobalConfig.LaserImpulseForce, ForceMode2D.Impulse);
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AsteroidGame
{
	public class Laser_Rotation_and_Destruction : MonoBehaviour
	{
		void Start()
		{
			transform.rotation = GameObject.FindWithTag("Player").transform.rotation;
			Destroy(gameObject, GlobalConfig.LaserSuicideTime);
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	public class Explosion : MonoBehaviour
	{
		Animator animator;

		void Start()
		{
			animator = GetComponent<Animator>();
			Destroy(gameObject, animator.GetCurrentAnimatorStateInfo(0).length);
		}
	}
}

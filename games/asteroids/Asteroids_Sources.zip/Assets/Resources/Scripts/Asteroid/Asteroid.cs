﻿using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	public class Asteroid : MonoBehaviour
	{
		#region Fields & Properties

		private Vector3 _startPosition;
		private Vector2 _forceDirection;
		private float _forceMagnitude;

		private int _scoreValue;

		protected GamePlayHUD hud;
		SpriteRenderer spriteRenderer;
		public Sprite[] asteroidSprites;

		[SerializeField]
		protected GameObject prefabExplosion;



		public Vector3 StartPosition
		{
			get { return _startPosition; }
			set { _startPosition = value; }
		}
		public Vector2 ForceDirection
		{
			get { return _forceDirection; }
			set { _forceDirection = value; }
		}
		public float ForceMagnitude
		{
			get { return _forceMagnitude; }
			set { _forceMagnitude = value; }
		}
		public int ScoreValue
		{
			get { return _scoreValue; }
			set { _scoreValue = value; }
		}

		#endregion


		//base constructor
		public Asteroid(Vector3 StartPosition, Vector2 ForceDirection, float ForceMagnitude, int ScoreValue)
		{
			_startPosition = StartPosition;
			_forceDirection = ForceDirection;
			_forceMagnitude = ForceMagnitude;
			_scoreValue = ScoreValue;
		}//constructor


		protected virtual void Start()
		{
			//apply constructor parameters
			gameObject.transform.position = StartPosition;
			GetComponent<Rigidbody2D>().AddForce(ForceDirection * ForceMagnitude, ForceMode2D.Impulse);

			//manage sprite
			spriteRenderer = GetComponent<SpriteRenderer>();
			
			int randValueSprite = (int)(Random.value * 10) % asteroidSprites.Length;
			spriteRenderer.sprite = asteroidSprites[randValueSprite];
			//print("sprite: " + randValueSprite);

			//get hud
			hud = GameObject.FindWithTag("HUD").GetComponent<GamePlayHUD>();
		}//start
	}
}

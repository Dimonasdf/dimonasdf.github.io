﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	public class AsteroidSmall : Asteroid
	{
		Timer switchLayerTimer;

		protected override void Start()
		{
			//AsteroidTemp layer
			gameObject.layer = 9;


			switchLayerTimer = gameObject.AddComponent<Timer>();
			switchLayerTimer.Duration = GlobalConfig.SwitchLayerTimerDuration;
			switchLayerTimer.Run();



			//set ScoreValue
			ScoreValue = GlobalConfig.SmallAsteroidScoreValue;

			//same as in Big, invoke base Start()
			base.Start();
		}//start

		private void Update()
		{
			if (switchLayerTimer.Finished)
			{
				//main Asteroid layer
				gameObject.layer = 8;
			}
		}

		void OnCollisionEnter2D(Collision2D collision)
		{
			if (collision.gameObject.tag == "Bullet")
			{
				//explosion
				Instantiate<GameObject>(prefabExplosion, gameObject.transform.position, Quaternion.identity);
				AudioManager.SfxPlay(AudioClipName.Explosion);

				//destruction
				Destroy(gameObject);

				//score
				ScoreHandler.AddPoints(ScoreValue);
				hud.UpdateScore();
			}
		}//oncollision


		public AsteroidSmall(Vector3 SmallStartPosition, Vector2 SmallForceDirection, float SmallForceMagnitude, int SmallScoreValue) : base(SmallStartPosition, SmallForceDirection, SmallForceMagnitude, SmallScoreValue)
		{
			SmallStartPosition = StartPosition;
			SmallForceDirection = ForceDirection;
			SmallForceMagnitude = ForceMagnitude;
			SmallScoreValue = ScoreValue;

		}//constructor

	}//class
}//namespace

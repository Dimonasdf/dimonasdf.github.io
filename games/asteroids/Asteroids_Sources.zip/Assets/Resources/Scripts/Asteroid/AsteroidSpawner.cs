﻿using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	public class AsteroidSpawner : MonoBehaviour
	{
		[SerializeField]
		GameObject prefabAsteroid;

		Timer timer;

		void Start()
		{
			timer = gameObject.AddComponent<Timer>();
			timer.Duration = GlobalConfig.BigAsteroidSpawnTime;
			timer.Run();
		}

		void Update()
		{
			if (timer.Finished)
			{
				Instantiate<GameObject>(prefabAsteroid);
				timer.Run();
			}
		}
	}
}

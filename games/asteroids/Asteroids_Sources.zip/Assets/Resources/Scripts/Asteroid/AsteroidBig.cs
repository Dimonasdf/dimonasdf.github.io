﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	public class AsteroidBig : Asteroid
	{
		//[SerializeField]
		//GameObject prefabExplosion;
		[SerializeField]
		GameObject prefabAsteroidSmall;

		Vector3 position;
		Vector2 direction;


		protected override void Start()
		{
			//set StartPosition
			int randValuePosition = (int)(Random.value * 10) % 4;
			switch (randValuePosition)
			{
				case 0:
					StartPosition = ScreenUtils.StartPositionLeft;
					break;
				case 1:
					StartPosition = ScreenUtils.StartPositionBot;
					break;
				case 2:
					StartPosition = ScreenUtils.StartPositionRight;
					break;
				case 3:
					StartPosition = ScreenUtils.StartPositionTop;
					break;
			}
			//print("position: " + randValuePosition);

			//set ForceDirection
			float baseAngle = Random.Range(0, Mathf.PI / 2);
			float angle = baseAngle - Mathf.PI / 4 + randValuePosition * Mathf.PI / 2;
			ForceDirection = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));

			//set ForceMagnitude
			ForceMagnitude = Random.Range(GlobalConfig.BigAsteroidMinInpulseForce, GlobalConfig.BigAsteroidMaxImpulseForce);

			//set ScoreValue
			ScoreValue = GlobalConfig.BigAsteroidScoreValue;

			//force base Asteroid Start(), which should be called _after_ this inherited Start()
			base.Start();
		}//start

		void OnCollisionEnter2D(Collision2D collision)
		{
			if (collision.gameObject.tag == "Bullet")
			{
				position = gameObject.transform.position;
				direction = ScreenUtils.ForceDirection(collision.gameObject);

				//explosion
				Instantiate<GameObject>(prefabExplosion, position, Quaternion.identity);
				AudioManager.SfxPlay(AudioClipName.Explosion, GlobalConfig.BigAsteroidExplosionPitch);

				//instantiate 2 small
				SpawnSmallAsteroid(1, 1.2f);
				SpawnSmallAsteroid(-1, 0.8f);

				//destruction
				Destroy(gameObject);
				
				//score
				ScoreHandler.AddPoints(ScoreValue);
				hud.UpdateScore();
			}
		}//oncollision

		Vector2 directionOffset = new Vector2(1f, 1f);

		GameObject SpawnSmallAsteroid(int offsetMult, float magMult)
		{
			GameObject smallAsteroid = Instantiate(prefabAsteroidSmall);

			smallAsteroid.GetComponent<AsteroidSmall>().StartPosition = position;
			smallAsteroid.GetComponent<AsteroidSmall>().ForceDirection = direction + offsetMult*directionOffset;
			smallAsteroid.GetComponent<AsteroidSmall>().ForceMagnitude = GlobalConfig.SmallAsteroidMagnitude * magMult;

			return smallAsteroid;
		}//spawnsmallasteroid



		public AsteroidBig(Vector3 BigStartPosition, Vector2 BigForceDirection, float BigForceMagnitude, int BigScoreValue) : base (BigStartPosition, BigForceDirection, BigForceMagnitude, BigScoreValue)
		{
		}//constructor

	}//class
}//namespace

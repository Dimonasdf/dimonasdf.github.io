﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


namespace AsteroidGame
{
	public class GamePlayHUD : MonoBehaviour
	{
		//scoring support
		[SerializeField]
		Text scoreText;

		[SerializeField]
		Text timeText;

		//[SerializeField]
		//Text playerNameText;
		//InputField playerNameInput;

		const string ScorePrefix = "Score: ";
		const string TimePrefix = "Time Alive: ";


		void Start()
		{
			//playerNameInput = playerNameText.GetComponent<InputField>();
			ScoreHandler.NullScore();
			scoreText.text = /*playerNameInput.text + " " + */ ScorePrefix + ScoreHandler.Score.ToString();
			timeText.text = TimePrefix + ScoreHandler.Time.ToString();

		}

		public void UpdateScore()
		{
			scoreText.text = /*playerNameInput.text + " " + */ ScorePrefix + ScoreHandler.Score.ToString();
		}

		private void Update()
		{
			ScoreHandler.Time += Time.deltaTime;
			timeText.text = TimePrefix + ScoreHandler.TimeToMinutes(ScoreHandler.Time);
		}
	}
}

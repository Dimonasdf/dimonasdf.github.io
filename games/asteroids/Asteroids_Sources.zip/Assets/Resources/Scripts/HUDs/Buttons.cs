﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


namespace AsteroidGame
{
	public static class Buttons
	{
		static string previousScene;

		public static void ButtonStart()
		{
			previousScene = SceneManager.GetActiveScene().name;
			MySceneManager.PlayScene(MenuNames.GamePlay);
		}

		public static void ButtonOptions()
		{
			previousScene = SceneManager.GetActiveScene().name;
			MySceneManager.PlayScene(MenuNames.Options);
		}

		public static void ButtonBack()
		{
			//MonoBehaviour.print(previousScene.ToString());
			SceneManager.LoadScene(previousScene);
		}

		public static void ButtonQuit()
		{
			Application.Quit();
		}
	}
}
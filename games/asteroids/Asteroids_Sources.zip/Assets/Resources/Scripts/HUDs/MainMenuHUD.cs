﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace AsteroidGame
{
	namespace AsteroidGame
	{
		public class MainMenuHUD : MonoBehaviour
		{
			public void MainMenuButton_Start()
			{
				Buttons.ButtonStart();
			}
			public void MainMenuButton_Options()
			{
				Buttons.ButtonOptions();
			}
			public void MainMenuButton_Quit()
			{
				Buttons.ButtonQuit();
			}
		}
	}
}

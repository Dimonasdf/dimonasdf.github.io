﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


namespace AsteroidGame
{
	public class EndMenuHUD : MonoBehaviour
	{
		[SerializeField]
		Text scoreText;
		const string FinalScorePrefix = "Final Score: ";
		const string FinalTimeAlivePrefix = "Total Time Alive: ";
		const string enter = "\n";


		void Start()
		{
			scoreText.text = FinalScorePrefix + ScoreHandler.Score.ToString() + enter + FinalTimeAlivePrefix + ScoreHandler.TimeToMinutes(ScoreHandler.Time);

		}


		public void EndMenuButton_Restart()
		{
			Buttons.ButtonStart();
		}
		public void EndMenuButton_Options()
		{
			Buttons.ButtonOptions();
		}
		public void EndMenuButton_Quit()
		{
			Buttons.ButtonQuit();
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace AsteroidGame
{
	public class OptionsMenuHUD : MonoBehaviour
	{
		public void OptionsMenuButton_Back()
		{
			Buttons.ButtonBack();
		}

		Slider[] volumeSliders;

		private void Start()
		{
			volumeSliders = GetComponentsInChildren<Slider>();

			volumeSliders[0].value = GlobalConfig.MasterVolume;
			volumeSliders[1].value = GlobalConfig.BgmVolume;
			volumeSliders[2].value = GlobalConfig.SfxVolume;
		}


		public void OptionsMenuSlider_AdjustMasterVolume(float masterSliderValue)
		{
			GlobalConfig.MasterVolume = masterSliderValue;
			AudioManager.bgmAudioSource.volume = GlobalConfig.MasterVolume * GlobalConfig.BgmVolume;
		}
		public void OptionsMenuSlider_AdjustSFXVolume(float effectsSliderValue)
		{
			GlobalConfig.SfxVolume = effectsSliderValue;
			AudioManager.sfxAudioSource.volume = GlobalConfig.MasterVolume * GlobalConfig.SfxVolume;
		}
		public void OptionsMenuSlider_AdjustBGMVolume(float musicSliderValue)
		{
			GlobalConfig.BgmVolume = musicSliderValue;
			AudioManager.bgmAudioSource.volume = GlobalConfig.MasterVolume * GlobalConfig.BgmVolume;
		}
	}
}

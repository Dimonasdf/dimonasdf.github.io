﻿using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;


namespace HungryCouchShooter
{
	public class HudHolder : MonoBehaviour
	{
		public TextMeshProUGUI scoreTextObject;

		public TextMeshProUGUI ammoTextObject;

		public TextMeshProUGUI hitPointsTextObject;

		public TextMeshProUGUI finalScoreTextObject;

		public GameObject endGamePanel;

		public void OnRestartButtonPressed()
		{
			//nullify statics, because it's just a reload of scene, and they are not discarded
			StaticUtilities.GameEnded = false;
			StaticUtilities.Score = 0;
			SceneManager.LoadScene(0);
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace HungryCouchShooter
{
	public class EnemySpawner : MonoBehaviour
	{
		protected float spawnCooldownTime = 10f;
		Timer spawnCooldownTimer;
		bool isSpawnCooldown;

		[SerializeField]
		Vector3[] spawnPoints = new Vector3[4];

		[SerializeField]
		GameObject[] enemyPrefab = new GameObject[3];


		void Start()
		{
			spawnCooldownTimer = gameObject.AddComponent<Timer>();
			spawnCooldownTimer.Duration = spawnCooldownTime;
			spawnCooldownTimer.Run();
		}


		void Update()
		{
			if (spawnCooldownTimer.Finished)
			{
				isSpawnCooldown = false;
				Instantiate(enemyPrefab[Random.Range(0, 3)], spawnPoints[Random.Range(0, 4)], Quaternion.identity);
				isSpawnCooldown = true;
				spawnCooldownTimer.Run();
			}
		}
	}
}

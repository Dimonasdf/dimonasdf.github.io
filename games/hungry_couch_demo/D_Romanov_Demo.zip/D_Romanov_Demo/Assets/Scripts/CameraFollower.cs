﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace HungryCouchShooter
{
	public class CameraFollower : MonoBehaviour
	{
		GameObject player;
		Vector2 playerPosition;

		Camera cameraComponent;
		Vector3 cameraPosition;

		float cameraSize;
		//float cameraLag;

		void Start()
		{
			player = GameObject.FindWithTag("Player");
			cameraComponent = transform.GetChild(0).GetComponent<Camera>();

			cameraSize = 5; //default value
			//cameraLag = 0;
		}

		void Update()
		{
			//zoom out feature here 
			if (player.GetComponent<Player>().IsCameraFunky == true)
			{
				cameraComponent.orthographicSize = (cameraSize + player.GetComponent<Rigidbody2D>().velocity.magnitude / 20);
			}

			//chase camera feature here
			transform.position = player.transform.position;
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class WeaponsHolder : MonoBehaviour
{
	public Object[] WeaponObjects;
	public GameObject[] WeaponGameObjects;

	public void Start()
	{
		//WeaponObjects = Resources.LoadAll("Prefabs/Weapons/Guns");
		
		//Does not work, that's why enemies are saved as prefabs, instead of dynamically loading them with random weapons
	}

}

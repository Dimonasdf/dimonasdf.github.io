﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace HungryCouchShooter
{
	public class WeaponParent : MonoBehaviour
	{
		#region Private Fields

		//protected string gunID;

		//protected string gunName;
		//protected string gunDescription;

		//protected float gunWeight; //you may move slower with bigger gun
		//protected float gunRotationOffset; //and rotate slower

		protected float shotCooldownTime; //time between shots
		Timer shotCooldownTimer;
		bool isShotCooldown = true;

		protected float reloadTime;
		Timer reloadTimer;
		bool isReloading = true;

		protected int totalMagazineCapacity;
		protected int currentlyBulletsInMagazine;

		//int bulletsPerShot = 1;


		[SerializeField]
		GameObject bulletPrefab;

		#endregion

		#region Public Properties

		//public string GunID { get { return gunID; } }
		public float ShotCooldownTime { get { return shotCooldownTime; } }
		public float ReloadTime { get { return reloadTime; } }
		public int BulletCapacity { get { return totalMagazineCapacity; } }
		public int BulletsInMag { get { return currentlyBulletsInMagazine; } }

		public bool IsReloading { get { return isReloading; } }

		#endregion


		#region Awake Start Update

		void Awake() //initialize editor components
		{
			shotCooldownTimer = gameObject.AddComponent<Timer>();
			reloadTimer = gameObject.AddComponent<Timer>();
		}

		public void Start()
		{
			//ammo values are not saved yet, so starting with empty mag and reloading
			//will prevent skipping reload entirely by reselecting the same weapon
			currentlyBulletsInMagazine = 0;

			shotCooldownTimer.Duration = shotCooldownTime;
			reloadTimer.Duration = reloadTime;

			shotCooldownTimer.Run();
			Reload();
		}


		public void Update()
		{
			if (shotCooldownTimer.Finished)
			{
				isShotCooldown = false;
			}
			if (reloadTimer.Finished)
			{
				isReloading = false;
			}
		}

		#endregion



		#region Class' Family Methods

		public void Fire(Vector3 _actorPosition, Quaternion _actorRotation, bool _isPlayer)
		{
			if (currentlyBulletsInMagazine == 0)
			{
				//print("Reload!");
			}
			else
			{
				if (isReloading)
				{
					//print("Is reloading.");
				}
				else
				{
					if (isShotCooldown)
					{
						//print("Vzvoditsya.");
					}
					else
					{
						if (_isPlayer)
						{
							Instantiate(bulletPrefab, _actorPosition, _actorRotation).layer = StaticUtilities.playerBulletsLayer;
						}
						else
						{
							Instantiate(bulletPrefab, _actorPosition, _actorRotation).layer = StaticUtilities.enemyBulletsLayer;
						}

						currentlyBulletsInMagazine -= 1;
						isShotCooldown = true;
						shotCooldownTimer.Run();
					}
				}
			}
			
		
		}

		public void Reload()
		{
			isReloading = true;
			reloadTimer.Run();

			currentlyBulletsInMagazine = totalMagazineCapacity;
		}

		#endregion

	}
}

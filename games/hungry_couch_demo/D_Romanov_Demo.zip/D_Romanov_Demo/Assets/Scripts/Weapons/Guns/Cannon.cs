﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace HungryCouchShooter
{
	public class Cannon : WeaponParent

	{
		new void Start()
		{
			//gunID = "0002";
			shotCooldownTime = 0.5f;
			reloadTime = 2;

			totalMagazineCapacity = 5;

			base.Start();
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace HungryCouchShooter
{
	public class AssaultRifle : WeaponParent

	{
		new void Start()
		{
			//gunID = "0001";
			shotCooldownTime = 0.1f;
			reloadTime = 1;

			totalMagazineCapacity = 30;

			base.Start();
		}
	}
}

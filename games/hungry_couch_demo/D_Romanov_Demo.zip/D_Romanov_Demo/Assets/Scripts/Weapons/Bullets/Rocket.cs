﻿
namespace HungryCouchShooter
{
	public class Rocket : BulletParent
	{

		new void Start()
		{
			bulletDamage = 25;
			bulletVelocity = 19;
			bulletLifetime = 2;

			bulletMass = 1.5f;

			base.Start();
		}
	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace HungryCouchShooter
{
	public class BulletParent : MonoBehaviour
	{
		#region Private Fields

		protected int bulletDamage;
		protected float bulletVelocity;
		protected float bulletLifetime; //basically - range

		protected float bulletMass;

		//due to current tilemap-based implementation bullets hitting walls will slide along them
		//checking for 0.01 speed drop will make this happen only at extremely low angles, which may also look like ricochet
		//may cause problems with registering actual target hits, but such behavior was not observed yet
		protected float velocityCutoff = 0.99f;

		protected string bulletTag;
		protected int bulletLayer;

		Rigidbody2D bulletRigidBody;
		Vector2 impulseDirection;

		#endregion

		#region Public Properties

		public int BulletDamage { get { return bulletDamage; } }
		public float BulletVelocity { get { return bulletVelocity; } }
		public float BulletLifetime { get { return bulletLifetime; } }

		#endregion



		#region Awake Start Update

		protected void Awake() //initialize editor components
		{
			bulletRigidBody = GetComponent<Rigidbody2D>();
		}

		protected void Start()
		{
			gameObject.tag = StaticUtilities.bulletTag;

			bulletRigidBody.mass = bulletMass;

			bulletRigidBody.AddRelativeForce(Vector3.up * bulletVelocity, ForceMode2D.Impulse);

			Destroy(gameObject, bulletLifetime);
		}

		
		void Update()
		{
			if(bulletRigidBody.velocity.magnitude * bulletRigidBody.mass < velocityCutoff * bulletVelocity)
			{
				Destroy(gameObject);
			}
		}

		#endregion

	}
}

﻿
namespace HungryCouchShooter
{
	public class Bullet : BulletParent
	{

		new void Start()
		{
			bulletDamage = 10;
			bulletVelocity = 20;
			bulletLifetime = 2;

			bulletMass = 1;
			
			base.Start();
		}
	}
}

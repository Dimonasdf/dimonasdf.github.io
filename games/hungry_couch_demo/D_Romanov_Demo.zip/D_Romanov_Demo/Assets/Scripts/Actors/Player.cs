﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace HungryCouchShooter
{
	public class Player : ActorParent
	{
		#region Private Fields

		bool isInputRaw = true;
		int motionPattern = 1;
		readonly float maxSpeed = 10; //actual max speed for one of the motion patterns

		bool isCameraFunky = false;

		//int playerScore;

		const string _ofInfinite = " / Inf";
		
		#endregion

		public bool IsCameraFunky { get { return isCameraFunky; } }

		#region Awake Start Update

		new void Start()
		{
			isPlayer = true;
			actorTag = StaticUtilities.playerTag;
			actorLayer = StaticUtilities.playerLayer;

			moveForce = 200;
			weight = 80;

			//0 to 60 - dependant on deltaTime
			//20 is already almost instant, 15 feels okay, 10-15 may be used for bulkier weapons
			rotationSpeed = 15;

			hitPoints = 100;

			motionDirection = new Vector2();

			hudAccessor.hitPointsTextObject.text = hitPoints.ToString();

			base.Start();
		}

		/* //funnyly enough, it changes nothing
		
		new void FixedUpdate()
		{
			base.FixedUpdate();
		}
		*/

		new void Update()
		{
			base.Update();

			if (!StaticUtilities.GameEnded)
			{
				CheckForShooterInput();
				CheckForVariousInput();

				UpdateWeaponInfoInHUD();
			}
		}

		#endregion



		#region Overrides

		override protected void Move()
		{
			if (isInputRaw)
			{
				motionDirection.x = Input.GetAxisRaw("Horizontal");
				motionDirection.y = Input.GetAxisRaw("Vertical");
			}
			else
			{
				motionDirection.x = Input.GetAxis("Horizontal");
				motionDirection.y = Input.GetAxis("Vertical");
			}
			motionDirection = motionDirection.normalized; //rip straferunning


			switch (motionPattern)
			{
				case 1: //Unity physics model movement (up is up on screen)
					{
						actorRigidBodyAccessor.AddForce(motionDirection * moveForce, ForceMode2D.Impulse);
						break;
					}

				case 2: //Unity physics model movement (up is "face forward", left is "left shoulder forward"), may be used for target locking situation (Dark Souls)
					{
						actorRigidBodyAccessor.AddRelativeForce(motionDirection * moveForce, ForceMode2D.Impulse);
						break;
					}

				case 3: //Set player RigidBody velocity directly, Unity physics are essentially lost
					{
						motionDirection = motionDirection * maxSpeed;
						actorRigidBodyAccessor.velocity = motionDirection;
						break;
					}

				case 4: //applying additional force to stop player when there is no input// may be developed further, but feels like a костыль, and should probably never exist
					{
						actorRigidBodyAccessor.AddForce(motionDirection * moveForce, ForceMode2D.Impulse);

						if (motionDirection == Vector2.zero)
						{
							actorRigidBodyAccessor.AddForce(-actorRigidBodyAccessor.velocity * 100, ForceMode2D.Impulse);
						}
						break;
					}

			}
		}

		//player looks at mouse
		override protected void Rotate()
		{
			lookDirection = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position; //vector from player position to mouse position
			lookDirectionAngle = Mathf.Atan2(lookDirection.y, lookDirection.x) * Mathf.Rad2Deg - 90; //angle in degrees from x axis to mouse position
			desiredRotation = Quaternion.AngleAxis(lookDirectionAngle, Vector3.forward); //calculating quaternion
			transform.rotation = Quaternion.Slerp(transform.rotation, desiredRotation, rotationSpeed * Time.deltaTime); //applying rotation with interpolation
		}


		override protected void OnCollisionEnter2D(Collision2D collision)
		{
			if (collision.gameObject.tag == "Bullet") //ok to call Bullet, as friendly and enemy bullets are in separate layers
			{
				hudAccessor.hitPointsTextObject.text = (hitPoints -= collision.gameObject.GetComponent<BulletParent>().BulletDamage).ToString();
				Destroy(collision.gameObject);

				if (hitPoints <= 0)
				{
					//death screen/sequence
					StaticUtilities.GameEnded = true;
					Time.timeScale = 0;
					hudAccessor.finalScoreTextObject.text = hudAccessor.scoreTextObject.text;
					hudAccessor.endGamePanel.SetActive(true);
				}
			}
		}
		#endregion



		#region Class' Personal Methods

		void CheckForShooterInput()
		{
			if (Input.GetButton("Fire1"))
			{
				ShootWeapon();
			}
			if (Input.GetButtonDown("1"))
			{
				EquipWeaponFromInventory(1);
			}
			if (Input.GetButtonDown("2"))
			{
				EquipWeaponFromInventory(2);
			}
			if (Input.GetButtonDown("3"))
			{
				EquipWeaponFromInventory(3);
			}
			if (Input.GetButtonDown("Reload"))
			{
				ReloadWeapon();
			}
		}
		
		void CheckForVariousInput() //should be moved away from Player on (much more) later stages
		{
			if (Input.GetButtonDown("ToggleInputMode"))
			{
				isInputRaw = !isInputRaw;
				print($"Input is raw: {isInputRaw}.");
			}

			if (Input.GetButtonDown("ToggleMovementPattern"))
			{
				if (motionPattern == 4)
					motionPattern = 1;
				else
					motionPattern += 1;

				print($"Motion Pattern : {motionPattern}.");
			}

			if (Input.GetButton("ModifyTimeScale"))
			{
				Time.timeScale = 0.1f;
				Time.fixedDeltaTime = 0.001f;
			}
			else
			{
				Time.timeScale = 1;
				Time.fixedDeltaTime = 0.01f;
			}

			if (Input.GetButtonDown("ToggleCameraZoom"))
			{
				isCameraFunky = !isCameraFunky;
				print($"Camera zooming out: {isCameraFunky}.");
			}
		}

		void UpdateWeaponInfoInHUD() //the only hud panel, updated in Update, because it is partially not connectable to any events //can be optimized later, if needed
		{
			if (EquippedWeaponObject == null)
			{
				hudAccessor.ammoTextObject.text = "No Weapon"; 
			}
			else
			{
				if (actorEquippedWeaponAccessor.IsReloading)
				{
					hudAccessor.ammoTextObject.text = "Reloading";
				}
				else
				{
					hudAccessor.ammoTextObject.text = actorEquippedWeaponAccessor.BulletsInMag.ToString() + _ofInfinite;
				}
			}
		}

		#endregion

	}
}

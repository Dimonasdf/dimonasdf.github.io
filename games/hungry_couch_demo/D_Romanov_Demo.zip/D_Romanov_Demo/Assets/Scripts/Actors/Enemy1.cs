﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace HungryCouchShooter
{
	public class Enemy1 : ActorParent
	{
		
		#region Awake Start Update

		new void Start()
		{
			isPlayer = false;
			actorTag = StaticUtilities.enemyTag;
			actorLayer = StaticUtilities.enemiesLayer;

			moveForce = 20;
			weight = 80;

			rotationSpeed = 10;

			hitPoints = 100;
			valuePoints = 25;
			
			motionDirection = Vector2.up;


			EquipWeaponFromInventory(1);

			base.Start();
		}

		new void Update()
		{
			//shortest AI code in history
			if (EquippedWeaponObject != null)
			{
				if(actorEquippedWeaponAccessor.BulletsInMag == 0)
				{
					ReloadWeapon();
				}

				ShootWeapon();
			}
			base.Update();
		}
		#endregion



		#region Class' Personal Methods

		#region Overrides
		override protected void OnCollisionEnter2D(Collision2D collision)
		{
			if (collision.gameObject.tag == "Bullet") //ok to call Bullet, as friendly and enemy bullets are in separate layers
			{
				hitPoints -= collision.gameObject.GetComponent<BulletParent>().BulletDamage;
				Destroy(collision.gameObject);

				if (hitPoints <= 0)
				{
					//instantiate dead sprite, play music here, whatever
					Destroy(gameObject);
					hudAccessor.scoreTextObject.text = (StaticUtilities.Score += valuePoints).ToString();
				}
			}
		}				
		
		override protected void Move()
		{
			actorRigidBodyAccessor.AddRelativeForce(motionDirection * moveForce, ForceMode2D.Impulse);
		}
		
		override protected void Rotate()
		{
			lookDirection = GameObject.FindWithTag("Player").transform.position - transform.position; //vector from enemy position to player position
			lookDirectionAngle = Mathf.Atan2(lookDirection.y, lookDirection.x) * Mathf.Rad2Deg - 90; //angle in degrees from x axis
			desiredRotation = Quaternion.AngleAxis(lookDirectionAngle, Vector3.forward); //calculating quaternion
			transform.rotation = Quaternion.Slerp(transform.rotation, desiredRotation, rotationSpeed * Time.deltaTime); //applying rotation with interpolation
		}

		#endregion

		#endregion

	}
}

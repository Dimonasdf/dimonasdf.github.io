﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;


namespace HungryCouchShooter
{
	public class ActorParent : MonoBehaviour
	{
		#region Private Fields

		protected bool isPlayer;
		protected string actorTag;
		protected int actorLayer;

		//protected bool canDash;
		//protected float dashDistance;

		//protected bool canBeHit;

		protected int hitPoints;
		protected int valuePoints;

		#region Movement Data
		protected int weight;

		protected float moveForce; //basically == weight * resulting movespeed //can be used as "personal muscle strength" or smth

		protected Vector2 motionDirection;
		protected float rotationSpeed;
		protected Quaternion currentRotation;
		protected Quaternion desiredRotation;

		protected Vector2 lookDirection;
		protected float lookDirectionAngle;

		#endregion

		protected Vector3 actorPosition;
		protected Quaternion actorRotation;

		protected Rigidbody2D actorRigidBodyAccessor;
		protected WeaponParent actorEquippedWeaponAccessor;
		protected HudHolder hudAccessor;

		[SerializeField]
		protected GameObject[] weaponInventoryObjects;

		[SerializeField]
		protected GameObject EquippedWeaponObject;

		#endregion

		#region Public Properties

		public bool IsPlayer { get { return isPlayer; } set { isPlayer = value; } }

		public float MoveSpeed { get { return moveForce; } set { moveForce = value; } }
		public float RotationSpeed { get { return rotationSpeed; } set { rotationSpeed = value; } }

		public int Weight { get { return weight; } set { weight = value; } }

		//public bool CanDash { get { return canDash; } set { canDash = value; } }
		//public float DashDistance { get { return dashDistance; } set { dashDistance = value; } }

		//public bool CanBeHit { get { return canBeHit; } set { canBeHit = value; } }

		public int HitPoints { get { return hitPoints; } set { hitPoints = value; } }

		public Vector2 LookDirection { get { return lookDirection; } }

		public Vector3 ActorPosition { get { return actorPosition; } }
		public Quaternion ActorRotation { get { return actorRotation; } }

		#endregion


		#region Awake Start Update

		protected void Awake() //initialize editor components
		{
			actorRigidBodyAccessor = gameObject.GetComponent<Rigidbody2D>();
			hudAccessor = GameObject.FindWithTag("HUD").GetComponent<HudHolder>();

			if (EquippedWeaponObject != null)
			{
				actorEquippedWeaponAccessor = EquippedWeaponObject.GetComponent<WeaponParent>();
			}
		}

		protected void Start()
		{
			gameObject.layer = actorLayer;
			actorRigidBodyAccessor.mass = weight;
		}
		
		protected void Update()
		{
			Move();
			Rotate();

			actorPosition = gameObject.transform.position;
			actorRotation = gameObject.transform.rotation;
		}

		#endregion



		#region Class' Family Methods

		#region Virtuals

		protected virtual void Move()
		{

		}

		protected virtual void Rotate()
		{

		}

		protected virtual void OnCollisionEnter2D(Collision2D collision)
		{

		}

		#endregion
		

		protected void EquipWeaponFromInventory(int number)
		{
			if (EquippedWeaponObject != null)
			{
				Destroy(EquippedWeaponObject);
			}

			if (weaponInventoryObjects[number - 1] == null)
			{
				print("Weapon sheathed.");
			}
			else
			{
				EquippedWeaponObject = Instantiate(weaponInventoryObjects[number - 1], transform);
				actorEquippedWeaponAccessor = EquippedWeaponObject.GetComponent<WeaponParent>();
			}
		}


		protected void ShootWeapon()
		{
			if (EquippedWeaponObject == null)
			{
				print("No weapon equipped");
			}
			else
			{
				actorEquippedWeaponAccessor.Fire(ActorPosition, ActorRotation, isPlayer);
			}
		}


		protected void ReloadWeapon()
		{
			if (EquippedWeaponObject == null)
			{
				print("No weapon equipped.");
			}
			else
			{
				actorEquippedWeaponAccessor.Reload();
			}
		}

		#endregion

	}
}

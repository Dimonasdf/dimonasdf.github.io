﻿namespace HungryCouchShooter
{
	public static class StaticUtilities
	{

		public static string playerTag = "Player";
		public static string bulletTag = "Bullet";
		public static string enemyTag = "Enemy";

		public static int playerLayer = 8;
		public static int playerBulletsLayer = 9;
		public static int enemiesLayer = 10;
		public static int enemyBulletsLayer = 11;

		public static int Score;

		public static bool GameEnded = false;
	}
}
